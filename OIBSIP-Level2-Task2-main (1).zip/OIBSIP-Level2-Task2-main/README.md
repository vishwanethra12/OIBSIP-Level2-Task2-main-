# Build-A-Tribute-Page
FreeCodeCamp.com Responsive Web Design Certification Project - "Build A Tribute Page"
https://www.freecodecamp.org/learn/responsive-web-design/responsive-web-design-projects/build-a-tribute-page
